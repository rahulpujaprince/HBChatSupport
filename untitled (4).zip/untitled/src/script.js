// Function to greet the user and show options
function greetUser() {
    const now = new Date();
    const hours = now.getHours();
    let greeting;

    if (hours < 12) {
        greeting = "Good morning";
    } else if (hours < 18) {
        greeting = "Good afternoon";
    } else {
        greeting = "Good evening";
    }

    const festivalMessage = checkFestival();
    const greetingMessage = festivalMessage ? `${greeting}, ${userName}! ${festivalMessage}` : `${greeting}, ${userName}!`;

    botResponse(greetingMessage);
    
    // Show the message to prompt user for options
    botResponse("Please choose from the available options:");
    showOptions(); // Show the options after greeting
}

// Function to show options for user to click
function showOptions() {
    const options = ["App not working", "Unable to Register", "What is company code", "When will I get my refund", "Food not good", "Vendor Complaint", "Kiosk Machine Problem"];
    options.forEach(option => {
        const button = document.createElement("button");
        button.classList.add("option-button");
        button.innerText = option;
        button.onclick = () => handleUserMessage(option);
        chatMessages.appendChild(button);
    });
    restartButton.style.display = 'block'; // Show restart button
    createTicketButton.style.display = 'block'; // Show create ticket button
}
